package com.example.flickrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.net.MalformedURLException;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);             //"Overcharge" / In a way that launch the activity
        setContentView(R.layout.activity_list);         //Set the activity xml

        MyAdapter myAdapter = new MyAdapter();
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(myAdapter);                         //Link the adapter the the listView

        try
        {
            AsyncFlickrJSONDataForList myTask = new AsyncFlickrJSONDataForList("https://www.flickr.com/services/feeds/photos_public.gne?tags=trees&format=json", myAdapter);     //Send the URL to check to the AsyncFlickrJSONData
            myTask.execute();                                           //Execute the task once it is created
        } catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
    }
}