package com.example.flickrapp;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class AsyncFlickrJSONData extends AsyncTask<String, Void, JSONObject>
{
    URL flickr_url = null;
    JSONObject myJSONObject = new JSONObject();

    public AsyncFlickrJSONData(String url) throws MalformedURLException
    {
        this.flickr_url = new URL(url);     //Store the url when we create the object
    }

    @Override
    protected JSONObject doInBackground(String... strings)      //Perform the HTTP connection, and reinstantiate the JSON object
    {
        try
        {
            HttpURLConnection urlConnection = (HttpURLConnection) flickr_url.openConnection();      //Open the connection using the url
            try
            {
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());           //Get the content of the urlConnection
                String s = readStream(in);                                                          //Read this content as a string
                Log.i("JFL", s);

                myJSONObject = new JSONObject(s);       //Create a JSON Object with the string we just translate
                in.close();                             //Close the input stream so we free resources
            } catch (JSONException e)
            {
                e.printStackTrace();
            } finally                           //the code inside will be done anyway
            {
                urlConnection.disconnect();     //Close the urlConnection, we don't need it anymore because we now have the JSON Object
            }
        } catch (MalformedURLException e)
        {
            e.printStackTrace();
        } catch (IOException e)
        {
            e.printStackTrace();
        }

        return myJSONObject;
    }

    @Override
    protected void onPostExecute(JSONObject jsonObject)     //Will be executed when the doInBackground is finished
    {
        Log.i("My JSON Object", myJSONObject.toString());

        try {
            String URL_image = myJSONObject
                    .getJSONArray("items")
                    .getJSONObject(0)
                    .getJSONObject("media")
                    .getString("m");
            Log.i("Url Image", URL_image);  //Print that to check if the url is valide

            AsyncBitmapDownloader bmd = new AsyncBitmapDownloader();
            bmd.execute(URL_image);         //Execute the AsyncBitmapDownloader with the image URL
        } catch (JSONException e)
        {
            e.printStackTrace();
        }
    }



    private String readStream(InputStream is)
    {
        try
        {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            int i = is.read();
            while(i != -1)
            {
                bo.write(i);
                i = is.read();
            }
            return bo.toString().replace("jsonFlickrFeed(", "");    //We replace something because with the "jsonFlickrFeed(" it is not read
        } catch (IOException e)
        {
            return "";
        }
    }
}
