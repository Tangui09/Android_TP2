package com.example.flickrapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class AsyncBitmapDownloader extends AsyncTask<String, Void, Bitmap>
{
    Bitmap bm;

    public AsyncBitmapDownloader() { }

    @Override
    protected Bitmap doInBackground(String... strings)              //String... = can give many strings
    {
        Log.i("AsyncBitmapDownloader", "Here");
        try
        {
            URL myUrl = new URL(strings[0]);                        //We only have one url, so we can take the first one we are sure to get the right one
            HttpURLConnection urlConnection = (HttpURLConnection) myUrl.openConnection();           //Open the connection using the url
            InputStream in = new BufferedInputStream((urlConnection.getInputStream()));             //Get the content of the urlConnection
            bm = BitmapFactory.decodeStream(in);                    //Decode the stream with a BitmapFactory, so we get a bitmap ready to be used as an image

            in.close();                                 //Close the input stream so we free ressources

        } catch (IOException e)
        {
            e.printStackTrace();
        }

        return bm;      //Send the "image" to next part
    }

    protected void onPostExecute(Bitmap bm)             //Log the obtained JSON object in Logcat
    {
        Log.i("onPost ABM", "Here");
        MainActivity.bm = bm;                           //Set MainActivity bitmap with the updated one
    }
}
