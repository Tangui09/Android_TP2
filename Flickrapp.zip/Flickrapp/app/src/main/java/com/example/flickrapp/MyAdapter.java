package com.example.flickrapp;

import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;

import java.util.Vector;

public class MyAdapter extends BaseAdapter
{
    private Vector<String> vector;

    public MyAdapter()
    {
        vector = new Vector<String>();
    }

    public void dd(String url)
    {
        vector.add(url);
        Log.i("JFL", "Adding to adapter url :" + url);
    }

    @Override
    public int getCount() {
        return vector.size();
    }

    @Override
    public Object getItem(int i) { return vector.get(i); }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup)
    {
        Log.i("JFL", "TODO");

        if (view == null)
        {
            LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
//            view = inflater.inflate(R.layout.textviewlayout, viewGroup, false);
//            ((TextView)view.findViewById(R.id.textViewList)).setText(vector.get(i));
            view = inflater.inflate(R.layout.bitmap_layout, viewGroup, false);
        }


        ImageView newimg = ((ImageView)view.findViewById(R.id.myImageView));    //Create the imageView so we can use it in the lambda expression
        RequestQueue queue = MySingleton.getInstance(viewGroup.getContext()).getRequestQueue();

        Response.Listener<Bitmap> rep = response -> { newimg.setImageBitmap(response);};

        ImageRequest req = new ImageRequest(vector.get(i), rep, 0, 0, ImageView.ScaleType.CENTER_CROP, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("JFL Error", "Volley Error");
                error.printStackTrace();
            }
        });
        queue.add(req); //Add the request to the queue

        return view;
    }
}
