package com.example.flickrapp;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.net.MalformedURLException;

public class GetImageOnClickListener implements View.OnClickListener
{
    @Override
    public void onClick(View v)
    {
        try
        {
            AsyncFlickrJSONData myTask = new AsyncFlickrJSONData("https://www.flickr.com/services/feeds/photos_public.gne?tags=trees&format=json");     //Send the URL to check to the AsyncFlickrJSONData
            myTask.execute();                                           //Execute the task once it is created
        } catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
    }
}
