package com.example.flickrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity
{
    String imageURL = "";
    public static Bitmap bm;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);                             //"Overcharge" / In a way that launch the activity
        setContentView(R.layout.activity_main);                         //Set the activity xml

        Button getImageButton = findViewById(R.id.getImageButton);
        getImageButton.setOnClickListener(new GetImageOnClickListener()     //Specific OnClickListener to get image on the url
        {
            @Override
            public void onClick(View v)
            {
                super.onClick(v);
                setRes(bm);             //Once we get the image in the bitmap, we display it
            }
        });


        Button sendImageButton = findViewById(R.id.sendButton);
        sendImageButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, ListActivity.class);    //Prepare the connection with ListActivity
                intent.putExtra("url", imageURL);                                    //Add the url to the intent so we can get it later
                startActivity(intent);                                                      //Launch the activity
            }
        });
    }

    public void setRes(Bitmap bitmap){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ImageView imageView = findViewById(R.id.imageToChange);     //Get the place to put the image
                imageView.setImageBitmap(bitmap);                           //Set the image stored in the bitmap (it's the good format for an image)
                Log.i("setRes", "Image set up");
            }
        });
    }

}