package com.example.lab2tp2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class AuthentificationActivity extends AppCompatActivity
{
    private String result = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.authentification_main);

        Button authentificate_button = findViewById(R.id.authentificate_button);
        authentificate_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                new Thread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        URL url = null;
                        try {
                            url = new URL("https://httpbin.org/basic-auth/bob/sympa");
                            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                            //Get name and password
                            EditText name_field = findViewById(R.id.nameField);
                            EditText password_field = findViewById(R.id.passwordField);
                            result = name_field.getText() + ":" + password_field.getText();

                            String basicAuth = "Basic " + Base64.encodeToString(result.getBytes(), Base64.NO_WRAP);
                            urlConnection.setRequestProperty ("Authorization", basicAuth);

                            try {
                                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                                String s = readStream(in);
                                Log.i("JFL", s);

                                TextView refreshTextView = findViewById(R.id.textView);
                                refreshTextView.setText(s);
                            } finally {
                                urlConnection.disconnect();
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }


    private String readStream(InputStream is)
    {
        try
        {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            int i = is.read();
            while(i != -1)
            {
                bo.write(i);
                i = is.read();
            }
            return bo.toString();
        }
        catch (IOException e)
        {
            return "";
        }
    }
}